<?php
/**
 * Plugin Name: Mijn Eerste Plugin
 * Plugin URI: https://example.com
 * Description: Een startpunt voor je vibe-coded plugin. Vervang deze code met wat de AI genereert.
 * Version: 1.0.0
 * Author: Workshop Deelnemer
 * Text Domain: mijn-eerste-plugin
 * License: GPL-2.0-or-later
 */

// Voorkom directe toegang tot dit bestand
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * ==========================================================
 * HIERONDER KOM JE CODE
 * Vervang dit blok met de code die je AI-tool genereert.
 * ==========================================================
 */

// Voorbeeld: toon een bericht boven elke post
add_filter( 'the_content', 'mep_voorbeeld_bericht' );

function mep_voorbeeld_bericht( $content ) {
	// Alleen op enkele berichten (niet op pagina's of overzichten)
	if ( is_single() ) {
		$bericht = '<p style="background: #f0f0f0; padding: 10px; border-left: 4px solid #0073aa;">
			🎉 Deze plugin werkt! Vervang deze code met je eigen creatie.
		</p>';
		return $bericht . $content;
	}
	return $content;
}
