=== Mijn Eerste Plugin ===
Contributors: workshop-deelnemer
Tags: workshop, vibe-coding, voorbeeld
Requires at least: 6.0
Tested up to: 6.7
Stable tag: 1.0.0
License: GPL-2.0-or-later

Een startpunt voor je vibe-coded plugin.

== Description ==

Deze plugin is gemaakt tijdens de workshop "Vibe Code je eigen WordPress Plugin".
Vervang de voorbeeldcode met je eigen AI-gegenereerde code.

== Changelog ==

= 1.0.0 =
* Eerste versie - workshop startpunt
