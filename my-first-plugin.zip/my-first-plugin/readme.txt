=== My First Plugin ===
Contributors: workshop-participant
Tags: workshop, vibe-coding, example
Requires at least: 6.0
Tested up to: 6.7
Stable tag: 1.0.0
License: GPL-2.0-or-later

A starting point for your vibe-coded plugin.

== Description ==

This plugin was created during the workshop "Vibe Code Your Own WordPress Plugin".
Replace the example code with your own AI-generated code.

== Changelog ==

= 1.0.0 =
* First version - workshop starting point
